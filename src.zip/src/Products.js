import React from "react";
import {connect} from "react-redux";

import "./Box.css";

import ProductDetails from "./Data/ProductDetails.json"

import {Link} from "react-router-dom"
import {Card} from "react-bootstrap"
const renderProduct =(card,index) =>{

    return(
        <Link to={`/Products/${card.id}`}>
        <Card style={{width:"25rem"}}  key={index} className="box">
  <Card.Img variant="top" src={card.image.img1} style={{width:"40",height:"20vw"}} />
  <Card.Body>
    <Card.Title>{card.title}</Card.Title>
    <Card.Text>
     {card.content}
    </Card.Text>
   
  </Card.Body>
</Card>
</Link>
    )

}

const Products =() =>
{
    console.log(this.props.Product)
    
   
    return(
        <div className="grid">
            {ProductDetails.map(renderProduct)}
              </div>
    ) 
}
const mapStatetoProps = state =>{
 return{  
     
      Product:state.cart
 }
    
}
export default connect(mapStatetoProps)(Products);