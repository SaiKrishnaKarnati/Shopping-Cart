import React, { useState } from "react"
import ProductDetails from "./Data/ProductDetails.json"
import {connect} from "react-redux"

import { Link } from "react-router-dom"

var mydatas = new Array();
var x = 0

const Addproducts = (id) => {

  console.log(id)
  mydatas[x] = id
  x = x + 1


  localStorage["mydatas"] = JSON.stringify(mydatas);


  localStorage.setItem('product_id', JSON.stringify(mydatas))

}

const Showproduct = ({ match }) => {


  return (
    <div>

      {
        ProductDetails.map(data => {
          if (data.id == match.params.id)
            return (
              <div className="container ">
                <div className="row">
                  <div className="col-md-6">
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                      <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img src={data.image.img1} class="d-block w-100" alt="FIrst Image" />
                        </div>
                        <div class="carousel-item">
                          <img src={data.image.img2} class="d-block w-100" alt="Second Image" />
                        </div>

                      </div>
                      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                      </a>

                    </div>

                  </div>
                  <div className="col-md-6"><br />
                    <div className="row">
                      <h2 >{data.title}</h2><br />

                    </div>
                    <div className="row">
                      <h2 className="display-3">{data.price}</h2>

                    </div>
                    <div className="row">
                      <blockquote class="blockquote">
                        <p class="mb-0">{data.details}</p>

                      </blockquote>

                    </div>
                    <br /><br /><br />
                    <div className="row">
                      {console.log(data.id)}
                      <button className="btn btn-primary" onClick={() => Addproducts(data.id)}><i class="fa fa-cart-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add to cart</button>&nbsp;&nbsp;
      <button className="btn btn-md btn-danger ml-4 text-light"><i class="fa fa-mobile fa-lg" aria-hidden="true"></i>


&nbsp;&nbsp;Buy now</button>
                    </div>
                  </div>
                </div>
              </div>




            )
        }
        )
      }

    </div>
  )
}
const mapStatetoProps =(state) => 
({

  
    data:state.ProductData
  
       
})
export default connect(mapStatetoProps)(Showproduct)