import React from "react";
import ProductDetails from "./Data/ProductDetails.json"
const CartProducts =() =>
{
   var products =localStorage.getItem('mydatas')
   console.log("hello")
   return(
      <div>
         <hr/>
         {products}
         <hr/>
      </div>
   )
    


    
}
export default CartProducts